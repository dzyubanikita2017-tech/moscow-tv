package com.example.appletvmoscowlauncher

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.content.pm.PackageManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 10, 13)
    private val white = Color.rgb(245, 246, 250)
    private val muted = Color.rgb(155, 160, 172)
    private val blue = Color.rgb(94, 156, 255)
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weather: TextView
    private lateinit var appRow: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()

    data class TvApp(val label: String, val packages: List<String>, val emoji: String)

    private val preferredApps = listOf(
        TvApp("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), "▶"),
        TvApp("VK Видео", listOf("ru.vk.video", "com.vk.vide"), "VK"),
        TvApp("Zona", listOf("com.zona"), "Z"),
        TvApp("V2RayTun", listOf("com.v2raytun.android", "com.v2raytun"), "⌁"),
        TvApp("Google Play", listOf("com.android.vending"), "✦")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(64), dp(38), dp(64), dp(28))
            setBackgroundColor(bg)
            gravity = Gravity.TOP
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "tv"
            textSize = 24f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        clock = TextView(this).apply {
            textSize = 34f; setTextColor(white)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.END
        }
        date = TextView(this).apply { textSize = 14f; setTextColor(muted); gravity = Gravity.END }
        weather = TextView(this).apply { text = "Москва · погода загружается…"; textSize = 14f; setTextColor(muted); gravity = Gravity.END }
        info.addView(clock); info.addView(date); info.addView(weather)
        top.addView(info)
        root.addView(top)

        val greeting = TextView(this).apply {
            text = "Что будем смотреть?"
            textSize = 30f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        val greetingParams = LinearLayout.LayoutParams(-1, -2)
        greetingParams.topMargin = dp(68)
        root.addView(greeting, greetingParams)

        val hint = TextView(this).apply {
            text = "Избранное"
            textSize = 15f
            setTextColor(muted)
        }
        val hintParams = LinearLayout.LayoutParams(-1, -2)
        hintParams.topMargin = dp(12)
        root.addView(hint, hintParams)

        appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val rowParams = LinearLayout.LayoutParams(-1, dp(142))
        rowParams.topMargin = dp(18)
        root.addView(appRow, rowParams)

        val footer = TextView(this).apply {
            text = "Нажми на приложение · минималистичный домашний экран"
            textSize = 12f
            setTextColor(Color.rgb(105, 110, 122))
        }
        val footerParams = LinearLayout.LayoutParams(-1, -2)
        footerParams.topMargin = dp(30)
        root.addView(footer, footerParams)

        setContentView(root)
        updateClock()
        drawApps()
        loadWeather()
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale("ru", "RU")).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale("ru", "RU")).format(now)
        clock.postDelayed({ updateClock() }, 30_000)
    }

    private fun drawApps() {
        appRow.removeAllViews()
        preferredApps.forEachIndexed { index, app ->
            val found = app.packages.firstOrNull { packageExists(it) }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = rounded(Color.rgb(24, 26, 33), 18)
                setPadding(dp(8), dp(12), dp(8), dp(10))
                elevation = dp(1).toFloat()
                setOnFocusChangeListener { v, focused ->
                    v.background = rounded(if (focused) Color.rgb(49, 57, 74) else Color.rgb(24, 26, 33), 18,
                        if (focused) blue else Color.rgb(46, 49, 58))
                    v.scaleX = if (focused) 1.04f else 1f
                    v.scaleY = if (focused) 1.04f else 1f
                }
                setOnClickListener {
                    if (found == null) {
                        Toast.makeText(this@MainActivity, "Не нашёл приложение «${app.label}». Можно указать его пакет отдельно.", Toast.LENGTH_LONG).show()
                    } else launchPackage(found)
                }
            }
            val icon = TextView(this).apply {
                text = app.emoji
                textSize = if (app.emoji.length > 1) 26f else 34f
                setTextColor(if (index == 0) Color.WHITE else blue)
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val label = TextView(this).apply {
                text = app.label
                textSize = 13f
                setTextColor(white)
                gravity = Gravity.CENTER
                maxLines = 1
            }
            card.addView(icon, LinearLayout.LayoutParams(-1, 0, 1f))
            val lpLabel = LinearLayout.LayoutParams(-1, -2)
            lpLabel.topMargin = dp(8)
            card.addView(label, lpLabel)
            val lp = LinearLayout.LayoutParams(0, -1, 1f)
            if (index > 0) lp.leftMargin = dp(14)
            appRow.addView(card, lp)
            if (index == 0) card.requestFocus()
        }
    }

    private fun packageExists(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0); true
    } catch (_: Exception) { false }

    private fun launchPackage(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "Приложение установлено, но не найден обычный способ запуска.", Toast.LENGTH_SHORT).show()
    }

    private fun loadWeather() {
        executor.execute {
            try {
                // Open-Meteo current weather for Moscow; no API key required.
                val raw = URL("https://api.open-meteo.com/v1/forecast?latitude=55.7558&longitude=37.6173&current=temperature_2m,weather_code&timezone=Europe%2FMoscow").readText()
                val temp = Regex(""temperature_2m"\s*:\s*(-?\d+(?:\.\d+)?)").find(raw)?.groupValues?.get(1)
                val code = Regex(""weather_code"\s*:\s*(\d+)").find(raw)?.groupValues?.get(1)?.toIntOrNull()
                val condition = when (code) {
                    0 -> "ясно"; 1, 2 -> "малооблачно"; 3 -> "пасмурно"
                    45, 48 -> "туман"; 51, 53, 55 -> "морось"
                    61, 63, 65 -> "дождь"; 71, 73, 75, 77 -> "снег"
                    80, 81, 82 -> "ливень"; 95, 96, 99 -> "гроза"
                    else -> "сейчас"
                }
                runOnUiThread { weather.text = if (temp != null) "Москва · $condition · ${temp.toDouble().toInt()}°C" else "Москва · погода недоступна" }
            } catch (_: Exception) {
                runOnUiThread { weather.text = "Москва · погода недоступна" }
            }
        }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int = color): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(2), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
